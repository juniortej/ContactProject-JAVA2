package fr.isen.java2.fxml;


public class AddPersonMenuController {

}
